#include <Windows.h>

#pragma comment(linker, "/EXPORT:NxCreatePhysicsSDK=_Repair206_NxCreatePhysicsSDK,@1")
#pragma comment(linker, "/EXPORT:NxCreatePhysicsSDKWithID=_Repair206_NxCreatePhysicsSDKWithID,@2")
#pragma comment(linker, "/EXPORT:NxGetCookingLib=_Repair206_NxGetCookingLib,@3")
#pragma comment(linker, "/EXPORT:NxGetCookingLibWithID=_Repair206_NxGetCookingLibWithID,@4")
#pragma comment(linker, "/EXPORT:NxGetFoundationSDK=_Repair206_NxGetFoundationSDK,@5")
#pragma comment(linker, "/EXPORT:NxGetPhysicsSDK=_Repair206_NxGetPhysicsSDK,@6")
#pragma comment(linker, "/EXPORT:NxGetPhysicsSDKAllocator=_Repair206_NxGetPhysicsSDKAllocator,@7")
#pragma comment(linker, "/EXPORT:NxGetUtilLib=_Repair206_NxGetUtilLib,@8")
#pragma comment(linker, "/EXPORT:NxReleasePhysicsSDK=_Repair206_NxReleasePhysicsSDK,@9")


PVOID pfnNxCreatePhysicsSDK;
PVOID pfnNxCreatePhysicsSDKWithID;
PVOID pfnNxGetCookingLib;
PVOID pfnNxGetCookingLibWithID;
PVOID pfnNxGetFoundationSDK;
PVOID pfnNxGetPhysicsSDK;
PVOID pfnNxGetPhysicsSDKAllocator;
PVOID pfnNxGetUtilLib;
PVOID pfnNxReleasePhysicsSDK;


#define EXTERNC extern "C"
#define NAKED __declspec(naked)
#define EXPORT __declspec(dllexport)

#define ALCPP EXPORT NAKED
#define ALSTD EXTERNC EXPORT NAKED void __stdcall
#define ALCFAST EXTERNC EXPORT NAKED void __fastcall
#define ALCDECL EXTERNC NAKED void __cdecl


namespace Repair206
{
	HMODULE m_hModule = NULL;
	DWORD m_dwReturn[9] = { 0 };

	FARPROC WINAPI GetAddress(PCSTR pszProcName)
	{
		FARPROC fpAddress;
		CHAR szProcName[16];
		TCHAR tzTemp[MAX_PATH];

		fpAddress = GetProcAddress(m_hModule, pszProcName);
		if (fpAddress == NULL)
		{
			if (HIWORD(pszProcName) == 0)
			{
				wsprintfA(szProcName, "%d", pszProcName);
				pszProcName = szProcName;
			}

			wsprintf(tzTemp, TEXT("error"), pszProcName);
			MessageBox(NULL, tzTemp, TEXT("Repair206"), MB_ICONSTOP);
			ExitProcess(-2);
		}

		return fpAddress;
	}

	inline VOID WINAPI InitializeAddresses()
	{
		pfnNxCreatePhysicsSDK = GetAddress("NxCreatePhysicsSDK");
		pfnNxCreatePhysicsSDKWithID = GetAddress("NxCreatePhysicsSDKWithID");
		pfnNxGetCookingLib = GetAddress("NxGetCookingLib");
		pfnNxGetCookingLibWithID = GetAddress("NxGetCookingLibWithID");
		pfnNxGetFoundationSDK = GetAddress("NxGetFoundationSDK");
		pfnNxGetPhysicsSDK = GetAddress("NxGetPhysicsSDK");
		pfnNxGetPhysicsSDKAllocator = GetAddress("NxGetPhysicsSDKAllocator");
		pfnNxGetUtilLib = GetAddress("NxGetUtilLib");
		pfnNxReleasePhysicsSDK = GetAddress("NxReleasePhysicsSDK");
	}

	inline BOOL WINAPI Load()
	{
		TCHAR tzPath[MAX_PATH];
		TCHAR tzTemp[MAX_PATH * 2];

		lstrcpy(tzPath, TEXT("PhysXLoaderOrg.dll"));
		m_hModule = LoadLibrary(tzPath);
		if (m_hModule == NULL)
		{
			wsprintf(tzTemp, TEXT("error"), tzPath);
			MessageBox(NULL, tzTemp, TEXT("Repair206"), MB_ICONSTOP);
		}
		else
		{
			InitializeAddresses();
		}

		return (m_hModule != NULL);
	}

	inline VOID WINAPI Free()
	{
		if (m_hModule)
		{
			FreeLibrary(m_hModule);
		}
	}
}
using namespace Repair206;




// HOOK_Thread  -> #201 #206
void HooK_Thread()
{
	Sleep(3000); //Wait for unzip DragonsagaMemory code
	DWORD old = NULL;
	DWORD address = (DWORD)GetModuleHandleA("dragonsaga.exe") + 0x5B9F6A;
	VirtualProtect((PVOID)address, 2, PAGE_EXECUTE_READWRITE, &old);
	*(BYTE*)(address + 0) = 0xEB;
	*(BYTE*)(address + 1) = 0x12;
	VirtualProtect((PVOID)address, 2, old, &old);
}





BOOL WINAPI DllMain(HMODULE hModule, DWORD dwReason, PVOID pvReserved)
{
	if (dwReason == DLL_PROCESS_ATTACH)
	{
		DisableThreadLibraryCalls(hModule);
		CloseHandle(CreateThread(NULL, NULL, (LPTHREAD_START_ROUTINE)HooK_Thread, NULL, NULL, NULL));
		return Load();
	}
	else if (dwReason == DLL_PROCESS_DETACH)
	{
		Free();
	}

	return TRUE;
}




ALCDECL Repair206_NxCreatePhysicsSDK(void)
{
	__asm JMP pfnNxCreatePhysicsSDK;
}
ALCDECL Repair206_NxCreatePhysicsSDKWithID(void)
{
	__asm JMP pfnNxCreatePhysicsSDKWithID;
}
ALCDECL Repair206_NxGetCookingLib(void)
{
	__asm JMP pfnNxGetCookingLib;
}
ALCDECL Repair206_NxGetCookingLibWithID(void)
{
	__asm JMP pfnNxGetCookingLibWithID;
}
ALCDECL Repair206_NxGetFoundationSDK(void)
{
	__asm JMP pfnNxGetFoundationSDK;
}
ALCDECL Repair206_NxGetPhysicsSDK(void)
{
	__asm JMP pfnNxGetPhysicsSDK;
}
ALCDECL Repair206_NxGetPhysicsSDKAllocator(void)
{
	__asm JMP pfnNxGetPhysicsSDKAllocator;
}
ALCDECL Repair206_NxGetUtilLib(void)
{
	__asm JMP pfnNxGetUtilLib;
}
ALCDECL Repair206_NxReleasePhysicsSDK(void)
{
	__asm JMP pfnNxReleasePhysicsSDK;
}
